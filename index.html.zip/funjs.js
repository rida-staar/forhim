// Show blue pill after 2 seconds
setTimeout(() => {
    const bluePill = document.getElementById('blue-pill');
    bluePill.classList.remove('hidden');
    bluePill.style.visibility = 'visible';
    bluePill.style.transform = 'scale(1.4)';
}, 2000);

// Show red pill after 3 seconds
setTimeout(() => {
    const redPill = document.getElementById('red-pill');
    redPill.classList.remove('hidden');
    redPill.style.visibility = 'visible';
    redPill.style.transform = 'scale(1.4)';
}, 3000);

// Click handler for the blue pill
document.getElementById('blue-pill').addEventListener('click', () => {
    // Automatically trigger the next page without confirmation

    // Hide the previous content (blue and red pills and other elements)
    document.body.innerHTML = ''; // Clear all existing content on the page

    // Change background to white
    document.body.style.backgroundColor = 'white';

    // Create a container for the question and options
    const container = document.createElement('div');
    container.style.position = 'absolute';
    container.style.top = '50%';
    container.style.left = '50%';
    container.style.transform = 'translate(-50%, -50%)';
    container.style.textAlign = 'center';

    // Create the question element
    const question = document.createElement('div');
    question.style.marginBottom = '20px';
    question.style.fontSize = '24px';
    question.style.fontWeight = 'bold';
    question.style.fontFamily = 'Press Start 2P, cursive'; // Apply pixel font style
    container.appendChild(question);

    // Add a link to the Google Fonts API for the pixel font
    const fontLink = document.createElement('link');
    fontLink.rel = 'stylesheet';
    fontLink.href = 'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap'; // Pixel font
    document.head.appendChild(fontLink);

    // Create the "Yes" button
    const yesButton = document.createElement('button');
    yesButton.textContent = 'Yes';
    yesButton.style.margin = '0 10px';
    yesButton.style.padding = '10px 20px';
    yesButton.style.fontSize = '18px';
    container.appendChild(yesButton);

    // Create the "No" button
    const noButton = document.createElement('button');
    noButton.textContent = 'No';
    noButton.style.margin = '0 10px';
    noButton.style.padding = '10px 20px';
    noButton.style.fontSize = '18px';
    container.appendChild(noButton);

    // Append the container to the body
    document.body.appendChild(container);

    // List of questions for "No" responses
    const questions = [
     "KFC polamm?","You and Me Final Destination padam?👉👈", "Ssshawarrmaa?","Saalaa Yes kuduraa","Ungaluku amma pudikum na yes kudunga😭", "OKAY..how about 5 GOLDEN POKEMON cards?", "Fine 8 cards", "Come on 10?", "En veetai paar ennai pidikum?", "Still NO?","nejamaavaa???","nejamaale nejamava?","nejamaalee nejamaalee nejamaava?","watha thirumba thirumba lan keka maaten" , "Eppo Varuva?", "Eppooo VARUVAA?", "Say Yes or Marry Danush?", "KNEW ITT", "Indha muyarchiyai paaratti oru Yes kudukkalame Prand🤧","WOULD U LIKE TO BE MY FHB","Yes= 720+ in neet", "last no?","Dinner Date?", "Say Yes?", "Pleeeeaaseuhh🥺", "Still Still NOO?","Azhagum arivum kalandhu ennai pol ulagil yarum illa ", "rizz question"
    ];
    let questionIndex = 0;

    // Function to update the question
    const updateQuestion = () => {
        // Remove any existing video or image
        const existingMedia = document.getElementById('dynamic-media');
        if (existingMedia) {
            existingMedia.remove();
        }

        // Handle the 15th question (index 14)
        if (questionIndex === 14) {
            // Update the question text
            question.textContent = questions[questionIndex];

            // Update the buttons for the 15th question
            yesButton.textContent = "Tomorrow";
            noButton.textContent = "Never";
            yesButton.style.order = 1; // "Tomorrow" on the left
            noButton.style.order = 2; // "Never" on the right
        }
        // Handle the 16th question (index 15)
        else if (questionIndex === 15) {
            // Add an image above the question text
            const image = document.createElement('img');
            image.id = 'dynamic-media';
            image.src = 'images/question_13_image.jpg'; // Path to the image for the 16th question
            image.alt = 'Question 13 Image';
            image.style.display = 'block';
            image.style.margin = '20px auto';
            image.style.width = '200px'; // Reduced width
            image.style.height = 'auto'; // Maintain aspect ratio
            container.insertBefore(image, question); // Insert the image above the question

            // Update the question text
            question.textContent = questions[questionIndex];

            // Update the buttons for the 16th question
            yesButton.textContent = "Tomorrow";
            noButton.textContent = "Never";
            yesButton.style.order = 1; // "Tomorrow" on the left
            noButton.style.order = 2; // "Never" on the right
        }
        // Handle the 17th question (index 16)
        else if (questionIndex === 16) {
            // Update the question text
            question.textContent = questions[questionIndex];

            // Update the buttons for the 17th question
            yesButton.textContent = "Yes";
            noButton.textContent = "Marry Danush"; // Replace "No" with "Marry Danush"
            yesButton.style.order = 1; // "Yes" on the left
            noButton.style.order = 2; // "Marry Danush" on the right
        }
        // Handle the 13th question (index 12)
        else if (questionIndex === 12) {
            // Update the question text
            question.textContent = questions[questionIndex];

            // Update the buttons for the 13th question
            yesButton.textContent = "Yes";
            noButton.textContent = "No";
            yesButton.style.order = 1; // "Yes" on the left
            noButton.style.order = 2; // "No" on the right
        }
        // Handle the 20th question (index 19)
        else if (questionIndex === 19) {
            // Add the GIF above the question text
            const gif = document.createElement('img');
            gif.id = 'dynamic-media';
            gif.src = 'images/home.gif'; // Path to the rizz.gif file
            gif.alt = 'HOME GIF';
            gif.style.display = 'block';
            gif.style.margin = '20px auto';
            gif.style.width = '300px'; // Adjust size as needed
            gif.style.height = 'auto'; // Maintain aspect ratio
            container.insertBefore(gif, question); // Insert the GIF above the question

            // Update the question text
            question.textContent = questions[questionIndex];

            // Update the buttons for the 20th question
            yesButton.textContent = "Yes";
            noButton.textContent = "No";
            yesButton.style.order = 1; // "Yes" on the left
            noButton.style.order = 2; // "No" on the right
        }
        // Handle the 21st question (index 20)
        else if (questionIndex === 20) {
            // Add the image above the question text
            const image = document.createElement('img');
            image.id = 'dynamic-media';
            image.src = 'images/bless.png'; // Path to the bless.png file
            image.alt = 'Bless Image';
            image.style.display = 'block';
            image.style.margin = '20px auto';
            image.style.width = '300px'; // Adjust size as needed
            image.style.height = 'auto'; // Maintain aspect ratio
            container.insertBefore(image, question); // Insert the image above the question

            // Update the question text
            question.textContent = questions[questionIndex];

            // Update the buttons for the 21st question
            yesButton.textContent = "Yes";
            noButton.textContent = "No";
            yesButton.style.order = 1; // "Yes" on the left
            noButton.style.order = 2; // "No" on the right
        }
        // Handle the 23rd question (index 22)
        else if (questionIndex === 22) {
            // Add the GIF above the question text
            const gif = document.createElement('img');
            gif.id = 'dynamic-media';
            gif.src = 'images/cook.gif'; // Path to the cook.gif file
            gif.alt = 'Cook GIF';
            gif.style.display = 'block';
            gif.style.margin = '20px auto';
            gif.style.width = '300px'; // Adjust size as needed
            gif.style.height = 'auto'; // Maintain aspect ratio
            container.insertBefore(gif, question); // Insert the GIF above the question

            // Update the question text
            question.textContent = questions[questionIndex];

            // Update the buttons for the 23rd question
            yesButton.textContent = "Yes";
            noButton.textContent = "No";
            yesButton.style.order = 1; // "Yes" on the left
            noButton.style.order = 2; // "No" on the right
        }
        // Handle the 26th question (index 25)
        else if (questionIndex === 25) {
            // Update the question text
            question.textContent = questions[questionIndex];

            // Update the buttons for the 26th question
            yesButton.textContent = "Yes";
            noButton.textContent = "No";
            yesButton.style.order = 1; // "Yes" on the left
            noButton.style.order = 2; // "No" on the right
        }
        // Handle the 27th question (index 26)
        else if (questionIndex === 26) {
            // Add the GIF above the question text
            const gif = document.createElement('img');
            gif.id = 'dynamic-media';
            gif.src = 'images/rizz.gif'; // Path to the rizz.gif file
            gif.alt = 'Rizz GIF';
            gif.style.display = 'block';
            gif.style.margin = '20px auto';
            gif.style.width = '300px'; // Adjust size as needed
            gif.style.height = 'auto'; // Maintain aspect ratio
            container.insertBefore(gif, question); // Insert the GIF above the question

            // Update the question text
            question.textContent = questions[questionIndex];

            // Update the buttons for the 27th question
            yesButton.textContent = "Yes";
            noButton.textContent = "No";
            yesButton.style.order = 1; // "Yes" on the left
            noButton.style.order = 2; // "No" on the right
        }
        // Handle the last question (index questions.length - 1)
        else if (questionIndex === questions.length - 1) {
            question.textContent = ''; // Remove the question text

            // Add a looping video
            const video = document.createElement('video');
            video.id = 'dynamic-media';
            video.src = 'images/video_final.mp4'; // Path to the video file
            video.type = 'video/mp4';
            video.autoplay = true;
            video.loop = true;
            video.muted = true; // Optional: Mute the video
            video.style.display = 'block';
            video.style.margin = '20px auto';
            video.style.width = '300px'; // Adjust size as needed
            container.insertBefore(video, yesButton); // Insert the video above the buttons

            // Update the buttons for the last question
            yesButton.textContent = "Yes";
            noButton.textContent = "Yes";

            // Swap the positions of "Yes" and "No" buttons
            yesButton.style.order = 2; // Move "Yes" to the right
            noButton.style.order = 1; // Move "Yes" to the left

            // Add event listener to sync both "Yes" options
            noButton.onclick = handleYesClick; // Sync with the final "Yes" option
        }
        // Handle all other questions
        else {
            question.textContent = questions[questionIndex];

            // Reset the buttons for other questions
            yesButton.textContent = "Yes";
            noButton.textContent = "No";
            yesButton.style.order = 1; // "Yes" on the left
            noButton.style.order = 2; // "No" on the right
        }
    };

    // Function to handle "Yes" click (shared for all "Yes" options)
    const handleYesClick = () => {
        // Clear the page content
        document.body.innerHTML = '';

        // Add the full-screen video
        const video = document.createElement('video');
        video.src = 'images/celebration.mp4'; // Path to the .mp4 video file
        video.type = 'video/mp4';
        video.autoplay = true;
        video.loop = false; // Play the video once
        video.muted = false; // Enable sound if needed
        video.style.position = 'fixed';
        video.style.top = '0';
        video.style.left = '0';
        video.style.width = '100%';
        video.style.height = '100%';
        video.style.objectFit = 'cover'; // Ensure the video fills the frame
        video.style.zIndex = '1000'; // Ensure it appears above all other elements
        document.body.appendChild(video);

        // Stop the video after 2 seconds and display the text and light effect
        setTimeout(() => {
            // Remove the video
            video.remove();

            // Add the full-screen light effect
            const lightEffect = document.createElement('div');
            lightEffect.classList.add('light-effect');
            document.body.appendChild(lightEffect);

            // Add the animated text
            const animatedText = document.createElement('div');
            animatedText.textContent = "EYYYY NIRANJANNN MOSSEHHH!!!";
            animatedText.style.fontSize = '32px';
            animatedText.style.fontWeight = 'bold';
            animatedText.style.textAlign = 'center';
            animatedText.style.position = 'fixed';
            animatedText.style.top = '20%';
            animatedText.style.left = '50%';
            animatedText.style.transform = 'translate(-50%, -50%)';
            animatedText.style.zIndex = '1001'; // Ensure it appears above the light effect
            animatedText.style.animation = 'fadeInOut 0.5s infinite'; // Faster fade-in and fade-out animation
            document.body.appendChild(animatedText);

            // Add the looping video on the left side
            const leftVideo = document.createElement('video');
            leftVideo.src = 'images/cat.mp4'; // Path to the looping video file
            leftVideo.type = 'video/mp4';
            leftVideo.autoplay = true;
            leftVideo.loop = true; // Play the video in a loop
            leftVideo.muted = true; // Optional: Mute the video
            leftVideo.style.position = 'fixed';
            leftVideo.style.top = '50%';
            leftVideo.style.left = '10%';
            leftVideo.style.transform = 'translateY(-50%)';
            leftVideo.style.width = '200px'; // Adjust size as needed
            leftVideo.style.zIndex = '1000';
            document.body.appendChild(leftVideo);

            // Add the looping video on the right side
            const rightVideo = document.createElement('video');
            rightVideo.src = 'images/cat.mp4'; // Path to the looping video file
            rightVideo.type = 'video/mp4';
            rightVideo.autoplay = true;
            rightVideo.loop = true; // Play the video in a loop
            rightVideo.muted = true; // Optional: Mute the video
            rightVideo.style.position = 'fixed';
            rightVideo.style.top = '50%';
            rightVideo.style.right = '10%';
            rightVideo.style.transform = 'translateY(-50%)';
            rightVideo.style.width = '200px'; // Adjust size as needed
            rightVideo.style.zIndex = '1000';
            document.body.appendChild(rightVideo);
        }, 2000); // 2-second delay
    };

    // Function to handle "No" click
    const handleNoClick = () => {
        if (questionIndex === questions.length - 1) {
            // Last question "No" click
            handleYesClick(); // Use the same behavior as "Yes" options
        } else {
            // Update the question on each "No" click
            questionIndex++;
            updateQuestion();
        }
    };

    // Start with the first question
    updateQuestion();

    // Attach event listeners
    yesButton.addEventListener('click', handleYesClick);
    noButton.addEventListener('click', handleNoClick);
});

// Click handler for the red pill
document.getElementById('red-pill').addEventListener('click', () => {
    // Clear the page content
    document.body.innerHTML = '';

    // Change background to white
    document.body.style.backgroundColor = 'white';

    // Add the text "Muditu bluepill edraa"
    const text = document.createElement('div');
    text.textContent = "MUDITU BLUEPILL EDRAA";
    text.style.fontSize = '30px';
    text.style.fontWeight = 'bold';
    text.style.color = 'black'; // Black font color
    text.style.textAlign = 'center';
    text.style.position = 'fixed';
    text.style.top = '30%';
    text.style.left = '50%';
    text.style.transform = 'translate(-50%, -50%)';
    text.style.opacity = '0'; // Start with opacity 0 for fade-in effect
    text.style.transition = 'opacity 1s'; // Fade-in effect
    text.style.zIndex = '1000';
    document.body.appendChild(text);

    // Trigger the fade-in effect for the text
    setTimeout(() => {
        text.style.opacity = '1'; // Fade in the text
    }, 50);

    // After 0.5 seconds, display the image with a fade-in effect
    setTimeout(() => {
        const image = document.createElement('img');
        image.src = 'images/thumb.jpg'; // Path to the thumb.jpg file
        image.alt = 'Thumb Image';
        image.style.display = 'block';
        image.style.margin = '0 auto';
        image.style.width = '300px'; // Adjust size as needed
        image.style.opacity = '0'; // Start with opacity 0 for fade-in effect
        image.style.transition = 'opacity 1s'; // Fade-in effect
        image.style.position = 'fixed';
        image.style.top = '65%';
        image.style.left = '50%';
        image.style.transform = 'translate(-50%, -50%)';
        image.style.zIndex = '1000';
        document.body.appendChild(image);

        // Trigger the fade-in effect for the image
        setTimeout(() => {
            image.style.opacity = '1'; // Fade in the image
        }, 50);

        // After 0.5 seconds, display the right-facing arrow below the image
        setTimeout(() => {
            const arrow = document.createElement('div');
            arrow.textContent = '→'; // Rightward-pointing arrow
            arrow.style.fontSize = '64px'; // Larger size
            arrow.style.fontWeight = 'bold';
            arrow.style.textAlign = 'center';
            arrow.style.cursor = 'pointer';
            arrow.style.color = 'black'; // Black arrow
            arrow.style.position = 'fixed';
            arrow.style.bottom = '10%';
            arrow.style.left = '50%';
            arrow.style.transform = 'translateX(-50%)';
            arrow.style.zIndex = '1000';
            document.body.appendChild(arrow);

            // Add click event to the arrow to navigate back to the previous slide
            arrow.addEventListener('click', () => {
                // Reload the red/blue pill slide
                location.reload(); // Reload the page to reset to the initial state
            });
        }, 500); // 0.5-second delay for the arrow
    }, 500); // 0.5-second delay for the image
});

